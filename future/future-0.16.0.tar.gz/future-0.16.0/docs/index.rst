Easy, clean, reliable Python 2/3 compatibility
==============================================

``python-future`` is the missing compatibility layer between Python 2 and
Python 3. It allows you to use a single, clean Python 3.x-compatible
codebase to support both Python 2 and Python 3 with minimal overhead.


.. include:: contents.rst.inc

