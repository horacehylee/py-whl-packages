# -*- test-case-name: twisted.words.test -*-
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""

Twisted X-ish: XML-ish DOM and XPath-ish engine

"""
