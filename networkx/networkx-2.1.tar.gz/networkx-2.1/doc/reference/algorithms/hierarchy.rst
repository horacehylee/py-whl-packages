*********
Hierarchy
*********

.. automodule:: networkx.algorithms.hierarchy
.. autosummary::
   :toctree: generated/

   flow_hierarchy
